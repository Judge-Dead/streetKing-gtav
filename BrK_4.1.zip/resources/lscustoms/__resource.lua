client_script 'lscustoms.lua'
server_script 'lscustoms_server.lua'