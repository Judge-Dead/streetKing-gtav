fooditems = {
	{ ['name'] = "Sandwich", ['value'] = 20, ['type'] = 2, ['price'] = 2 },
	{ ['name'] = "Soda", ['value'] = 20, ['type'] = 1, ['price'] = 5 },
}
