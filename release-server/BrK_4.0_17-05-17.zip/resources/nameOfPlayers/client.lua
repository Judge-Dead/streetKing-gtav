AddEventHandler("playerSpawned", function(spawn)
    TriggerServerEvent("cp:spawnplayer")	
end)