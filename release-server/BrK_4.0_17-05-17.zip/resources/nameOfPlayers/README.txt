--------------------------------------------------------
                    NameOfPlayers
-------------------------------------------------------

This script is for you GTA V server on FiveM.
NEED ESSENTIALS's SCRIPT TO WORK !

You have to edit your database and set a new column :
- Name of the column : Nom
- Default value of the column : null

Now restart your server. When a player enter in your server, his name is register
in your database. It's more friendly when you have lot of players on your server
and when you want identify them more quickly !!

Have fun 