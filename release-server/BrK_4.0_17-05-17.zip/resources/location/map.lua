
spawnpoint 'a_m_y_bevhills_02' { x = -890.93, y = -2311.53, z = -3.50 }

--