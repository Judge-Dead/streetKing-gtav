server_script 'adverts_server.lua'
client_script 'adverts_client.lua'
