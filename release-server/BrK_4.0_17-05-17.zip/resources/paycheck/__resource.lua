server_script 'paycheck_sv.lua'
client_script 'paycheck_cl.lua'
