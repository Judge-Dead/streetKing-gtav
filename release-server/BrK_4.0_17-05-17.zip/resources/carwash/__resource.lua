client_script 'carwash_client.lua'
server_script 'carwash_server.lua'
