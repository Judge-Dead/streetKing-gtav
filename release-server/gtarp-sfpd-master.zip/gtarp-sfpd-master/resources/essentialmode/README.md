# fivem-essentialmode
A resource for FiveM to make resource creation easier and allows for easy communication between them.
