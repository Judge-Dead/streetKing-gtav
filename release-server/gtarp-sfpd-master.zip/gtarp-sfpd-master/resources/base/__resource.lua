
server_script 'config.lua'
server_script 'server.lua'
server_script 'spawn/process.lua'

client_script 'client.lua'
client_script 'spawn/spawnManager.lua'
client_script 'knockout/knockout.lua'

