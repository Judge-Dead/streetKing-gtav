

RegisterServerEvent("base:debug")
AddEventHandler("base:debug", function(_)
    print(_)
end)