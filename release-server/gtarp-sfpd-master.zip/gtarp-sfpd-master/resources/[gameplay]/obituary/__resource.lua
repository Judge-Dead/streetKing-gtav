dependency 'channelfeed'

client_script 'obituary.lua'

export 'printObituary'

files 'obituary.css'
