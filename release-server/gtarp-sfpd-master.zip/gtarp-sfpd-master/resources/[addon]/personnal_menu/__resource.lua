--
-- Created by IntelliJ IDEA.
-- User: Djyss
-- Date: 09/05/2017
-- Time: 09:55
-- To change this template use File | Settings | File Templates.
--
server_scripts {
    '../../essentialmode/config.lua',
    'server.lua'
}
client_script {
    'client.lua',
    'GUI.lua'
}

export 'getQuantity'
export 'notFull'