
client_script 'keysControl.lua'
client_script 'lib/menuClass.lua'
client_script 'clothes/menu.lua'
client_script 'barbers/menu.lua'
client_script 'ammunations/menu.lua'

server_script '../../essentialmode/config.lua'
server_script 'process.lua'
