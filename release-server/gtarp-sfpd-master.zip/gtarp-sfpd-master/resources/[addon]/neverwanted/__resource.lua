description 'Disables AI Cops'

client_script 'nowanted.lua'