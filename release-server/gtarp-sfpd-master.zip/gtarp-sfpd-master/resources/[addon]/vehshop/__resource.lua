client_script 'vehshop.lua'
server_script '../../essentialmode/config.lua'
server_script 'vehshop_s.lua'

export 'ShowVehshopBlips'