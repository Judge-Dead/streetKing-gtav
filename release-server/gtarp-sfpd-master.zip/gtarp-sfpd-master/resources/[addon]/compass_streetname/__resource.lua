resource_manifest_version "77731fab-63ca-442c-a67b-abc70f28dfa5"
description "MsQuerade's Compass and Streetname HUD"
version "1.0"

client_scripts {
	"essentials.lua",
	"compass.lua",
	"streetname.lua"
}
