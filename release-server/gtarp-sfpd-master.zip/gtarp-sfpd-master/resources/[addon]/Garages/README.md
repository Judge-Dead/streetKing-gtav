# garages v3

See intructions :

https://forum.fivem.net/t/release-garages-v2-1-17-04-17-updated/13066
