server_script '../../essentialmode/config.lua'
server_scripts {
	'server.lua'
}

client_script {
	'client.lua',
	'GUI.lua'
}
