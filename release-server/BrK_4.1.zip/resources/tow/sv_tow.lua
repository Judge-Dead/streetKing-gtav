TriggerEvent('es:addCommand', 'tow', function(source, args, user)

	TriggerClientEvent('pv:tow', source)

end)