resource_manifest_version '77731fab-63ca-442c-a67b-abc70f28dfa5'

dependency 'essentialmode'

client_script 'foodshops_cl.lua'
client_script 'foodGUI.lua'
server_script 'foodshops_sv.lua'
server_script 'fooditems_sv.lua'