client_script 'scripts/client/c.lua'
server_script 'scripts/server/s.lua'
server_script 'settings.lua'