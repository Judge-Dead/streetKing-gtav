-- type in your database info below.
mySQL = {
host = "localhost",
db = "game",
inttable = "interiors",
login = "root",
pass = "1202"
}
--------- [ DO NOT TOUCH] ---------
require "resources/interiors/mysql/MySQL" -- MySql.lua path
mysqlpath = 'resources/interiors/mysql/MySql.Data.dll' -- MySql.Data.dll path
-----------------------------------