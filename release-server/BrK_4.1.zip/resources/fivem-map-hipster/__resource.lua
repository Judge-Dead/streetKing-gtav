resource_type 'map' { gameTypes = { es_roleplay = true } }

map 'map.lua'
