client_script 'vehshop.lua'
server_script 'vehshop_server.lua'

export 'ShowVehshopBlips'