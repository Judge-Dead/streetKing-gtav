client_script "foodhud.net.dll"
file "foodhud_config.ini"