dependency 'vdk_inventory'

server_scripts {
	'config.lua',
	'server.lua'
}

client_script {
	'vdkrec.lua'
}