--
-- Created by IntelliJ IDEA.
-- User: Djyss
-- Date: 10/05/2017
-- Time: 13:50
-- To change this template use File | Settings | File Templates.
--

anims = {
    hello = {
        lib = "gestures@m@standing@casual",
        anim = "gesture_hello"
    }
}